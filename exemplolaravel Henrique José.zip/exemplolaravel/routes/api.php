<?php

use App\Http\Controllers\LivrosController;
use App\Http\Controllers\TarefaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/tarefa', [TarefaController::class, 'index']);

Route::get('/tarefa/find/{id}', [TarefaController::class, 'show']);

Route::post('/tarefa', [TarefaController::class, 'store']);

Route::put('/tarefa', [TarefaController::class, 'update']);

Route::delete('/tarefa/delete/{id}', [TarefaController::class, 'delete']);

Route::get('/tarefa/search', [TarefaController::class, 'search']);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Route::get('/livros', [LivrosController::class, 'index']);

Route::get('/livros/find/{id}', [LivrosController::class, 'show']);

Route::post('/livros', [LivrosController::class, 'store']);

Route::put('/livros', [LivrosController::class, 'update']);

Route::delete('/livros/delete/{id}', [LivrosController::class, 'delete']);

Route::get('/livros/search', [LivrosController::class, 'search']);

Route::get('/livros/ordenar', [LivrosController::class, 'listar']);