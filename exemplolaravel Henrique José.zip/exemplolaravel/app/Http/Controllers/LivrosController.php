<?php

namespace App\Http\Controllers;

use App\Models\Livros;
use Illuminate\Http\Request;

class LivrosController extends Controller
{
    public function index()
    {
        $livros = Livros::all();

        return response()->json([
            'status' => true,
            'data' => $livros
        ]);
    }

    public function store(Request $request)
    {
        $livros = Livros::create([
            'titulo' => $request->titulo,
            'autor' => $request->autor,
            'ano_publicacao' => $request->ano_publicacao,
            'genero' => $request->genero,
            'descricao' => $request->descricao,
            'editora' => $request->editora,
            'isbn' => $request->isbn,
            'selo_editorial' => $request->selo_editorial
        ]);

        return response()->json([
            'status' => true,
            'message' => 'cadastrado',
            'data' => $livros
        ]);
    }

    public function show($id)
    {
        $livros = Livros::find($id);

        if ($livros == null) {
            return response()->json([
                'status' => false,
                'message' => 'Livro não encontrado'
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'livro encontrado com sucesso',
            'data' => $livros
        ]);
    }

    public function update(Request $request)
    {
        $livros = Livros::find($request->id);

        if ($livros == null) {
            return response()->json([
                'status' => false,
                'message' => 'Tarefa não encontrada'
            ]);
        }

        if (isset($request->titulo)) {
            $livros->titulo = $request->titulo;
        }

        if (isset($request->autor)) {
            $livros->autor = $request->autor;
        }

        if (isset($request->ano_publicacao)) {
            $livros->ano_publicacao = $request->ano_publicacao;
        }

        if (isset($request->genero)) {
            $livros->genero = $request->genero;
        }

        if (isset($request->descricao)) {
            $livros->descricao = $request->descricao;
        }

        if (isset($request->editora)) {
            $livros->editora = $request->editora;
        }

        if (isset($request->isbn)) {
            $livros->isbn = $request->isbn;
        }

        if (isset($request->selo_editorial)) {
            $livros->selo_editorial = $request->selo_editorial;
        }

        $livros->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado'
        ]);
    }

    public function delete($id)
    {
        $livros = Livros::find($id);

        if ($livros == null) {
            return response()->json([
                'status' => false,
                'message' => 'Não encontrada'
            ]);
        }

        $livros->delete();

        return response()->json([
            'status' => true,
            'message' => 'Excluido'
        ]);
    }

    public function search(Request $request)
    {

        if ($request->tipo_pesquisa == "titulo") {
            $livros = Livros::where('titulo', 'like', '%' . $request->pesquisa . '%')->get();
        }


        if ($request->tipo_pesquisa == "autor") {
            $livros = Livros::where('autor', 'like', '%' . $request->pesquisa . '%')->get();
        }

        if ($request->tipo_pesquisa == "isbn") {
            $livros = Livros::where('isbn', 'like', '%' . $request->pesquisa . '%')->get();
        }
        return response()->json([
            'status' => true,
            'data' => $livros
        ]);
    }

    public function ordenar(Request $request){
        
    }
}
