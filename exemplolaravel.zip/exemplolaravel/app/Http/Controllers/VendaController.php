<?php

namespace App\Http\Controllers;

use App\Models\Venda;
use Illuminate\Http\Request;

class VendaController extends Controller
{
    public function store(Request $request)
    {  
        
     $venda = Venda::create([ 
     'cliente_id' =>$request->cliente_id,
     'data_venda' => $request->data_venda,
     'subtotal' => $request->subtotal,
     'desconto' => $request->desconto,
     'total' => $request->total
      ]); 
        
     return response()->json([  
     'status'=> true, 
     'message'=> 'cadastrado', 
     'data'=> $venda
      ]); 

    } 
}
