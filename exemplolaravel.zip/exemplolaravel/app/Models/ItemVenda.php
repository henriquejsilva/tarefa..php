<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ItemVenda extends Model
{
    use HasFactory;

    protected $fillable = [
        'venda_id',
        'produto_id',
        'quantidade',
        'preco_unitario',
        'subtotal_item'
    ];

    public function venda(): HasMany
    {
        return $this->hasMany(Venda::class);
    }

    public function produto(): HasMany
    {
        return $this->hasMany(Produto::class);
    }
}
