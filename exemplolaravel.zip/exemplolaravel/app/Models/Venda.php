<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Venda extends Model
{
    use HasFactory;

    protected $fillable = [
        'cliente_id',
        'data_venda',
        'subtotal',
        'desconto',
        'total'
    ];

    public function comments(): HasMany
    {
        return $this->hasMany(Cliente::class);
    }
}
