<?php

use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ProdutoController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/clientes', [ClienteController::class, 'store']);

Route::get('/clientes', [ClienteController::class, 'index']);

Route::get('/clientes/{id}', [ClienteController::class, 'show']);

Route::put('/clientes/find/{id}', [ClienteController::class, 'update']);

Route::delete('/clientes/find/{id}', [ClienteController::class, 'delete']);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Route::post('/produtos', [ProdutoController::class, 'store']);

Route::get('/produtos', [ProdutoController::class, 'index']);

Route::get('/produtos/{id}', [ProdutoController::class, 'show']);

Route::put('/produtos/find/{id}', [ProdutoController::class, 'update']);

Route::delete('/produtos/find/{id}', [ProdutoController::class, 'delete']);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Route::post('/produtos', [ProdutoController::class, 'store']);